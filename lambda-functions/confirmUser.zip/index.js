const AWS = require('aws-sdk');
const cognito = new AWS.CognitoIdentityServiceProvider();

exports.handler = async (event) => {
    const { username, userPoolId } = event;

    console.log("Event : ", event);

    const params = {
        UserPoolId: userPoolId,
        Username: username,
    };

    try {
        // Confirm the user without requiring a confirmation code
        const data = await cognito.adminConfirmSignUp(params).promise();
        console.log('User confirmed:', data);

        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'User confirmed successfully',
                data: data
            }),
        };
    } catch (error) {
        console.error('Error confirming user:', error);

        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Error confirming user',
                error: error.message,
            }),
        };
    }
};
