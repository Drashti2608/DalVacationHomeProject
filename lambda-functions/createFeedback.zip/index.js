const { DynamoDBClient, PutItemCommand } = require('@aws-sdk/client-dynamodb');
const { LanguageServiceClient } = require('@google-cloud/language')
const { v4: uuidv4 } = require('uuid');

const dynamodbClient = new DynamoDBClient({ region: 'us-east-1' });

const clientEmail = process.env.GCP_CLIENT_EMAIL;
const privateKey = process.env.GCP_PRIVATE_KEY.replace(/\\n/g, '\n');

const languageClient = new LanguageServiceClient({
    credentials: {
        client_email: clientEmail,
        private_key: privateKey,
    }
});

const analyzeSentimentOfFeedback = async (text) => {

    const document = {
        content: text,
        type: 'PLAIN_TEXT',
    };

    try {
        const [result] = await languageClient.analyzeSentiment({ document });
        console.log("Result : ", result);
        const sentiment = result.documentSentiment;
        return sentiment.score >= 0.25 ? 'POSITIVE' : sentiment.score <= -0.25 ? 'NEGATIVE' : 'NEUTRAL';
    } catch (err) {
        console.error('Error analyzing sentiment:', err);
        throw new Error("Error analyzing sentiment")
    }

}

exports.handler = async (event) => {

    try {

        console.log("Event : ", event);
        const { roomId, userId, feedbackText } = event;
        const feedbackId = uuidv4();
        const timestamp = Date.now().toString();
        const sentiment = await analyzeSentimentOfFeedback(feedbackText);

        // if (!sentiment) {
        //     return {
        //         statusCode: 500,
        //         body: JSON.stringify({message:"Error analyzing sentiment."})
        //     }
        // }

        const params = {
            TableName: 'roomFeedback',
            Item: {
                'roomId': { S: roomId },
                'feedbackId': { S: feedbackId },
                'userId': { S: userId },
                'feedbackText': { S: feedbackText },
                'timestamp': { N: timestamp },
                'sentiment': { S: sentiment }
            }
        };

        await dynamodbClient.send(new PutItemCommand(params));

        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Feedback added successfully." }),
        };

    } catch (error) {
        console.error('Error while processing feedback:', error);

        if (error.message === 'Error analyzing sentiment') {
            // Handle specific error for sentiment analysis failure (more informative message)
            return {
                statusCode: 500, // Or other relevant code for sentiment analysis failure (e.g., 422)
                body: JSON.stringify({
                    message: "An error occurred while analyzing the sentiment of your feedback. Please try again later.",
                }),
            };
        } else {
            // Handle other errors with a generic message
            return {
                statusCode: 500, // Or a more specific code if possible
                body: JSON.stringify({ error: 'Internal server error' }),
            };
        }
    }
};
